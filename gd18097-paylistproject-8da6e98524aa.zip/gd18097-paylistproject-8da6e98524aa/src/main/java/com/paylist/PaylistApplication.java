package com.paylist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaylistApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaylistApplication.class, args);
	}

}
