package com.paylist.models;

public enum Status {

    PAID,
    PENDING,
    CANCELLED,
    REFUNDED
}
